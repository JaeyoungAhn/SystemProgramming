#include <stdio.h>
int main() {
	printf("Hello, KNU CSE!!\n");
	return 0;
}
